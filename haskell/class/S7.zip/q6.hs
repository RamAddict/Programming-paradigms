

main = do
    print (min 2 4)
    print (max 3 6)