O'Haskell é um fork do haskell, porem extendido com subtipagem estatica e objetos monadicos.
Segundo a página recuperada no wayBack machine, O'Haskell também é uma linguagem orientada
a objetos imperativa com polimorfismo parametrico e inferência automática de tipos. Além 
disso possui suporte à programação concorrente.