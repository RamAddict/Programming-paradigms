

main = do
    print (ceiling 29.23)
    print (floor 29.23)